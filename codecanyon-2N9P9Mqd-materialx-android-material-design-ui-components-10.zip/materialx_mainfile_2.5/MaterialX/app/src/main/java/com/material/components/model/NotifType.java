package com.material.components.model;

public enum NotifType {
    NORMAL,
    LINK,
    IMAGE
}
