package com.material.components.model;

import java.io.Serializable;

public class DeviceInfo implements Serializable {

    public String device;
    public String os_version;
    public String app_version;
    public String serial;
    public String regid;

}
