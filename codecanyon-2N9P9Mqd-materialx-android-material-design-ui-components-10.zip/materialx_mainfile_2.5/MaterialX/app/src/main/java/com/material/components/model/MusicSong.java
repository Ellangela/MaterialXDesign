package com.material.components.model;

import android.graphics.drawable.Drawable;

public class MusicSong {

    public int image;
    public Drawable imageDrw;
    public String title;
    public String brief;

}
