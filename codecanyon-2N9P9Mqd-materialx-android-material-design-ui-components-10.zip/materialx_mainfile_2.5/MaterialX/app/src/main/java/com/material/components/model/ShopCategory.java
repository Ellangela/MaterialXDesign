package com.material.components.model;

import android.graphics.drawable.Drawable;

public class ShopCategory {

    public int image;
    public Drawable imageDrw;
    public String title;
    public String brief;
    public int image_bg;

    public ShopCategory() {
    }

}
