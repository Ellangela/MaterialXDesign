package com.material.components.activity.button;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

import com.material.components.R;

public class ButtonBasic extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_button_basic);
    }
}
