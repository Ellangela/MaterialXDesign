package com.material.components.model;

import android.graphics.drawable.Drawable;

public class MusicAlbum {

    public int image;
    public Drawable imageDrw;
    public String name;
    public String brief;
    public int color;

}
